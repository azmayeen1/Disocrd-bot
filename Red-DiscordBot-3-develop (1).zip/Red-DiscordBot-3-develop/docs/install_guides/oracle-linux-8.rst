.. _install-oracle-linux-8:

======================================
Installing Red on Oracle Linux 8.6-8.x
======================================

.. include:: _includes/install-guide-rhel8-derivatives.rst
