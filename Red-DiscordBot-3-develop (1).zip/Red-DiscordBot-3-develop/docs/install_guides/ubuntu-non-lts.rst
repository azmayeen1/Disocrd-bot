.. _install-ubuntu-non-lts:

=========================================
Installing Red on Ubuntu non-LTS versions
=========================================

Latest Ubuntu non-LTS version (24.10 at the time of writing) is not supported at current time
due to lack of availability of Python 3.11 or older in its repositories.

The support should come back once we get back on track with supporting current Python versions.

We recommend usage of latest Ubuntu **LTS** versions instead, you can find
`an install guide for Ubuntu 24.04 <ubuntu-2404>` in our docs.
