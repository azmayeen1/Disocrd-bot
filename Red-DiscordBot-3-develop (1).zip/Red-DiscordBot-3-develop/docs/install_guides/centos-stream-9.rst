.. _install-centos-stream-9:

=================================
Installing Red on CentOS Stream 9
=================================

.. include:: _includes/install-guide-rhel9-derivatives.rst
