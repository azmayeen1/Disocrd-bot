.. _install-rhel-9:

=========================================================
Installing Red on Red Hat Enterprise Linux (RHEL) 9.2-9.x
=========================================================

.. include:: _includes/install-guide-rhel9-derivatives.rst
