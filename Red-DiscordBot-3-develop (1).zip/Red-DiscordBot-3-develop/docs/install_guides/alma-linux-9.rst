.. _install-alma-linux-9:

==============================
Installing Red on Alma Linux 9
==============================

.. include:: _includes/install-guide-rhel9-derivatives.rst
